# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

from django.conf.urls import include, url
from django.contrib.auth import views as auth_views

from snowchain.django.site import views
from snowchain.django.site.forms import SnowchainAuthenticationForm

urlpatterns_base = [
  # Customize some auth view setup.
  url('^auth/login/$', auth_views.LoginView.as_view(authentication_form=SnowchainAuthenticationForm)),
  # Use the other auth views as-is.
  url(r'^auth/', include('django.contrib.auth.urls')),

  url(r'^healthz$', views.Healthz.as_view(), name='healthz'),
  url(r'^dbz$', views.Dbz.as_view(), name='dbz'),
  url(r'^dbz/backends$', views.DbzBackends.as_view(), name='dbz_backends'),
  url(r'^dbz/backends/data$', views.DbzBackendsData.as_view(), name='dbz_backends_data'),
  url(r'^dbz/locks$', views.DbzLocks.as_view(), name='dbz_locks'),
  url(r'^dbz/locks/data$', views.DbzLocksData.as_view(), name='dbz_locks_data'),
  url(r'^dbz/bgwriter', views.DbzBgWriter.as_view(), name='dbz_bgwriter'),
]
