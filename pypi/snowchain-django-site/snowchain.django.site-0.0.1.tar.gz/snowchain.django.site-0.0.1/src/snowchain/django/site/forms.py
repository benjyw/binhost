# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

from django.contrib.auth.forms import AuthenticationForm


class SnowchainAuthenticationForm(AuthenticationForm):
  heading = 'Please sign in:'
  submit_text = 'Login'
  class_prefix = 'login'

  def __init__(self, *args, **kwargs):
    kwargs['label_suffix'] = ''  # Drop the ':' suffix, since we use the label as a placeholder in text inputs.
    super(SnowchainAuthenticationForm, self).__init__(*args, **kwargs)
