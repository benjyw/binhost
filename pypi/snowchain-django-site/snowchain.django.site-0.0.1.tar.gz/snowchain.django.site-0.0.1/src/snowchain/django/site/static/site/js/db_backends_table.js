var snowchain = snowchain || {};

snowchain.dbz = snowchain.dbz || {};

snowchain.dbz.initBackendsTable = function(selector, dataUrl) {
  function formatCode(val) {
    return '<code>' + val + '</code>'
  }

  var tableOptions = {
    url: dataUrl,
    showRefresh: true,
    showToggle: true,
    showColumns: true,
    sortName: 'state',
    search: false,
    idField: 'pid',
    rowStyle: function(row) {
      return {
        classes: 'state-' + row.state
      };
    },
    columns:
        [
          {
            title: 'pid',
            field: 'pid',
            align: 'left',
            valign: 'top',
            class: 'pid'
          },
          {
            title: 'db',
            field: 'datname',
            align: 'left',
            valign: 'top',
            class: 'datname',
            sortable: true
          },
          {
            title: 'client',
            field: 'client',
            align: 'left',
            valign: 'top',
            class: 'client',
            sortable: true
          },
          {
            title: 'user',
            field: 'usename',
            align: 'left',
            valign: 'top',
            class: 'user',
            sortable: true
          },
          {
            title: 'state',
            field: 'state',
            align: 'left',
            valign: 'top',
            class: 'state',
            sortable: true
          },
          {
            title: 'connected',
            field: 'backend_start',
            align: 'left',
            valign: 'top',
            formatter: snowchain.site.util.elapsedSince,
            class: 'backend_start',
            sortable: true
          },
          {
            title: 'xact start',
            field: 'xact_start',
            align: 'left',
            valign: 'top',
            formatter: snowchain.site.util.elapsedSinceWithMillis,
            class: 'xact_start',
            sortable: true
          },
          {
            title: 'query start',
            field: 'query_start',
            align: 'left',
            valign: 'top',
            formatter: snowchain.site.util.elapsedSinceWithMillis,
            class: 'query_start',
            sortable: true
          },
          {
            title: 'query',
            field: 'query',
            align: 'left',
            valign: 'top',
            class: 'query',
            formatter: formatCode,
            sortable: true
          }
        ]
  };
  snowchain.table.initTable(selector, tableOptions);
};
