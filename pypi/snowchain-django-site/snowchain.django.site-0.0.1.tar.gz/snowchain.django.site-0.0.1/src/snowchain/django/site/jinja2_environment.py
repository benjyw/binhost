# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

from datetime import datetime

from django.contrib.staticfiles.storage import staticfiles_storage
from django.urls import reverse
from django.utils import timezone
from jinja2 import Environment

UNIX_EPOCH = datetime.fromtimestamp(0, tz=timezone.utc)


_date_fmt = '%Y/%m/%d'
_time_fmt = '%H:%M:%S'
_ms_fmt = '%f'

def datetime_fmt_std(dt, abbrev=False, ms=False):
  if dt is None:
    return None
  if dt == UNIX_EPOCH:
    return '-'
  if abbrev and dt.date() == datetime.today().date():
    fmt = '%H:%M:%S'
  else:
    fmt = '%Y/%m/%d %H:%M:%S'
  if ms:
    fmt += '.{}'.format(_ms_fmt)
    return dt.strftime(fmt)[:-3]
  return dt.strftime(fmt)

def seconds_from_now(dt):
  now = timezone.now()
  if dt is None or dt <= now:
    return 0
  else:
    return (dt - now).seconds

def add_class(bound_field, val):
  existing_classes = bound_field.field.widget.attrs.get('class')
  new_classes = '{} {}'.format(existing_classes, val) if existing_classes else val
  bound_field.field.widget.attrs['class'] = new_classes
  return bound_field


def form_class(form, cls):
  suffix = getattr(form, 'class_suffix', None)
  if suffix:
    return '{cls} {cls}-{suffix}'.format(cls=cls, suffix=suffix)
  else:
    return cls


def environment(**options):
  options['autoescape'] = True
  options['extensions'] = ['jinja2.ext.autoescape']
  env = Environment(**options)
  env.globals.update({
    'static': staticfiles_storage.url,
    'url': reverse,
    'form_class': form_class,
  })
  env.filters.update({
    'add_class': add_class,
    'datetime_fmt_std': datetime_fmt_std,
    'seconds_from_now': seconds_from_now,
  })
  return env
