# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import textwrap
from collections import OrderedDict

from django.conf import settings
from django.db import connection
from django.http import HttpResponse
from django.views import View
from django.views.generic import TemplateView

from snowchain.django.util.view_util import AjaxView, SuperuserOnlyMixin


class Healthz(View):
  def get(self, _):
    return HttpResponse('OK')


class Dbz(SuperuserOnlyMixin, TemplateView):
  template_name = 'site/dbz.html'


class DbzBackends(SuperuserOnlyMixin, TemplateView):
  template_name = 'site/dbz_backends.html'


class DbzLocks(SuperuserOnlyMixin, TemplateView):
  template_name = 'site/dbz_locks.html'


class DbzBgWriter(SuperuserOnlyMixin, TemplateView):
  template_name = 'site/dbz_bgwriter.html'

  def get_bgwriter_stats(self):
    with connection.cursor() as cursor:
      cursor.execute(textwrap.dedent('SELECT * FROM pg_stat_bgwriter'))
      columns = [col[0] for col in cursor.description]
      return OrderedDict(zip(columns, cursor.fetchall()[0]))


class DbzBackendsData(SuperuserOnlyMixin, AjaxView):
  returns_list = True

  def get_ajax_data(self):
    if settings.DATABASES['default']['ENGINE'] != 'django.db.backends.postgresql':
      raise NotImplementedError('dbz only implemented for PostgreSQL.')

    username = self.request.GET.get('u')
    if username == 'me':
      username = settings.DATABASES['default']['USER']

    with connection.cursor() as cursor:
      # Note that 'usename' is not a typo.
      if username:
        cursor.execute('SELECT * FROM pg_stat_activity where usename=%s', [username])
      else:
        cursor.execute('SELECT * FROM pg_stat_activity')
      columns = [col[0] for col in cursor.description]
      rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
      for x in rows:
        x['client'] = '{}:{}'.format(x['client_addr'], x['client_port']) if x['client_addr'] else ''
      return rows


class DbzLocksData(SuperuserOnlyMixin, AjaxView):
  returns_list = True

  def get_ajax_data(self):
    if settings.DATABASES['default']['ENGINE'] != 'django.db.backends.postgresql':
      raise NotImplementedError('dbz only implemented for PostgreSQL.')

    with connection.cursor() as cursor:
      cursor.execute('SELECT current_database()')
      current_db_name = cursor.fetchall()[0][0]

      cursor.execute(textwrap.dedent("""
        SELECT pid, datname, locktype, relname, mode, granted
        FROM pg_locks as pl 
        LEFT JOIN pg_database as pd ON pl.database = pd.oid
        LEFT JOIN pg_class as pc ON pl.relation = pc.oid
      """))
      columns = [col[0] for col in cursor.description]
      ret = [dict(zip(columns, row)) for row in cursor.fetchall()]
      for row in ret:
        # The relname computed by the join is correct only if we're on the current db (or no db).
        # See https://www.postgresql.org/docs/9.6/static/view-pg-locks.html.
        if row['datname'] and row['datname'] != current_db_name:
          row['relname'] = ''
      return ret
