var snowchain = snowchain || {};

snowchain.site = snowchain.site || {};

snowchain.site.util = snowchain.site.util || {};

snowchain.site.util._dateFmt = 'YYYY/MM/DD';
snowchain.site.util._timeFmt = 'HH:mm:ss';
snowchain.site.util._millisFmt = '.SSS';

snowchain.site.util.dateToStr = function(val, withMillis) {
  if (!val) {
    return '';
  }
  var dt = moment(val).utc();
  if (dt.isSame(moment(0))) {
    return '-';  // This is the UNIX epoch.
  }
  var fmt = snowchain.site.util._dateFmt + ' ' + snowchain.site.util._timeFmt;
  if (withMillis) {
    fmt += snowchain.site.util._millisFmt;
  }
  return dt.format(fmt);
};

snowchain.site.util.dateToStrWithMillis = function(val) {
  return snowchain.site.util.dateToStr(val, true);
};

snowchain.site.util.shortenDateTime = function(val, withMillis) {
  var dt_str = snowchain.site.util.dateToStr(val, withMillis);

  function maybeTruncate(prefix) {
    if (dt_str.startsWith(prefix)) {
      dt_str = dt_str.substring(prefix.length);
      return true;
    }
    return false;
  }

  var now = moment().utc();
  var today = now.format(snowchain.site.util._dateFmt);
  if (!maybeTruncate(today + ' ')) {
    maybeTruncate(now.year() + '/');
  }
  return dt_str;
};

snowchain.site.util.shortenDateTimeWithMillis = function(val) {
  return snowchain.site.util.shortenDateTime(val, true);
};

snowchain.site.util.elapsedSince = function(val, withMillis) {
  if (!val) {
    return '';
  }
  var diffMillis = moment().diff(val);
  var ms = diffMillis % 1000;
  var diffSecs = Math.floor(diffMillis / 1000);
  var secs = diffSecs % 60;
  var diffMins = Math.floor(diffSecs / 60);
  var mins = diffMins % 60;
  var diffHours = Math.floor(diffMins / 60);
  var hours = diffHours % 24;
  var days = Math.floor(diffHours / 24);

  var ret = '';

  function pad(num, len) {
    var str = num.toString();
    // Only pad if there's a prefix. E.g., 1m02.123s, but just 2.123s.
    return (ret !== '' && str.length < len) ? pad('0' + str, len) : str;
  }

  var numParts = 0;

  if (days > 0) {
    ret = ret + days.toString() + 'd';
    numParts += 1;
  }
  if (hours > 0) {
    ret = ret + pad(hours, 2) + 'h';
    numParts += 1;
  }
  if (numParts < 2) {
    if (mins > 0) {
      ret = ret + pad(mins, 2) + 'm';
      numParts += 1;
    }
    if (numParts < 2) {
      if (secs > 0) {
        ret = ret + pad(secs, 2);
        numParts += 1;
      }
      if (numParts < 2) {
        if (ret === '') {
          ret = '0';
        }
        if (withMillis) {
          ret = ret + '.' + pad(ms, 3);
          numParts += 1;
        }
        ret = ret + 's';
      }
    }
  }
  return ret;
};

snowchain.site.util.elapsedSinceWithMillis = function(val) {
  return snowchain.site.util.elapsedSince(val, true);
};
