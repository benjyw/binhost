var snowchain = snowchain || {};

snowchain.dbz = snowchain.dbz || {};

snowchain.dbz.initLocksTable = function(selector, dataUrl) {
  var tableOptions = {
    url: dataUrl,
    showRefresh: true,
    showToggle: true,
    showColumns: true,
    sortName: 'state',
    search: false,
    idField: 'pid',
    rowStyle: function(row) {
      return {
        classes: 'state-' + row.state
      };
    },
    columns:
        [
          {
            title: 'pid',
            field: 'pid',
            align: 'left',
            valign: 'top',
            class: 'pid'
          },
          {
            title: 'db',
            field: 'datname',
            align: 'left',
            valign: 'top',
            class: 'datname',
            sortable: true
          },
          {
            title: 'type',
            field: 'locktype',
            align: 'left',
            valign: 'top',
            class: 'locktype',
            sortable: true
          },
          {
            title: 'mode',
            field: 'mode',
            align: 'left',
            valign: 'top',
            class: 'mode',
            sortable: true
          },
          {
            title: 'granted',
            field: 'granted',
            align: 'left',
            valign: 'top',
            class: 'granted',
            sortable: true
          },
          {
            title: 'relation',
            field: 'relname',
            align: 'left',
            valign: 'top',
            class: 'relname',
            sortable: true
          }
        ]
  };
  snowchain.table.initTable(selector, tableOptions);
};
