# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import logging.config
import os

# Various useful default Django settings.  Apps can import them and override as needed.

SITE_ROOT = os.sep.join(os.path.abspath(__file__).split(os.sep)[0:-6])


# Set up logging without allowing Django to add its defaults, as they are notoriously difficult to override properly.

LOGGING_CONFIG = None

LOGGING = {
  'version': 1,
  'formatters': {
    'default': {
      'format': '[%(asctime)s %(levelname)s %(filename)s:%(lineno)s] %(message)s',
      'datefmt': '%Y-%m-%d %H:%M:%S'
    }
  },
  'handlers': {
    'console': {
      'class': 'logging.StreamHandler',
      'level': 'DEBUG',
      'formatter': 'default'
    },
  },
  'loggers': {
    # Everything will propagate to the root logger.  Note that the special name 'root' represents the logger at
    # the root of the dotted-string hierarchy, and which you'd logically expect to be represented by an empty string.
    'root': {
      'handlers': ['console'],
      'level': 'WARNING'
    },
    'django': {
      'handlers': ['console'],
      'level': 'INFO'
    },
    'django.db.backends': {
      'handlers': ['console'],
      'level': 'INFO',  # Set to DEBUG to see live SQL queries.
      'propagate': False,
    },
    'snowchain': {
      'handlers': ['console'],
      'level': 'INFO'
    },
  }
}

logging.config.dictConfig(LOGGING)


# All the standard middleware.

MIDDLEWARE_CLASSES = (
  'django.contrib.sessions.middleware.SessionMiddleware',
  'django.middleware.common.CommonMiddleware',
  'django.middleware.csrf.CsrfViewMiddleware',
  'django.contrib.auth.middleware.AuthenticationMiddleware',
  'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
  'django.contrib.messages.middleware.MessageMiddleware',
  'django.middleware.clickjacking.XFrameOptionsMiddleware',
  'django.middleware.security.SecurityMiddleware',
)


# Timezone settings.
TIME_ZONE = 'UTC'
USE_TZ = True


# Template settings.

TEMPLATES = [
  {
    'BACKEND': 'django.template.backends.jinja2.Jinja2',
    'APP_DIRS': True,
    'OPTIONS': {
      'environment': 'snowchain.django.site.jinja2_environment.environment'
    },
  },
]


# URL and other settings.

APPEND_SLASH = True

STATIC_URL = '/static/'

STATIC_ROOT = os.path.join(SITE_ROOT, 'staticfiles')

STATICFILES_FINDERS = (
  'django.contrib.staticfiles.finders.FileSystemFinder',
  'django.contrib.staticfiles.finders.AppDirectoriesFinder',
)

LOGIN_URL = '/auth/login/'
LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = LOGIN_URL

CSRF_USE_SESSIONS = True


# Basic apps shared by all our binaries.

INSTALLED_APPS = (
  'django.contrib.auth',
  'django.contrib.contenttypes',
  'django.contrib.messages',
  'django.contrib.postgres',  # For full-text search.
  'django.contrib.sessions',
  'django.contrib.staticfiles',
  'snowchain.django.site',
)

# Env-specific settings.

SNOWCHAIN_ENV = os.environ.get('SNOWCHAIN_ENV', 'snowchain_dev')

if SNOWCHAIN_ENV == 'snowchain_dev':
  DEBUG = True

  # If you set this to True, you are responsible for running a local PostgreSQL server.
  # E.g., `initdb ~/pgsql.data` to set up a data dir, and then `postgres -D ~/pgsql.data`.
  DEV_POSTGRES = True

  if DEV_POSTGRES:
    DATABASES = {
      'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'postgres',
      }
    }
  else:
    DATABASES = {
      'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': '.snowchain.sqlite3',
      }
    }

  try:
    from snowchain.django.site.settings_local import *
  except ImportError:
    from snowchain.django.util.create_settings_local import ensure_settings_local
    ensure_settings_local(__file__)
    from snowchain.django.site.settings_local import *

elif SNOWCHAIN_ENV == 'snowchain_prod':
  # SECURITY WARNING: don't run with debug turned on in production!
  # Turn this on as a last resort, to debug production issues that don't
  # reproduce in a dev environment.
  if 'TEMPORARY_PROD_DEBUG_MODE_REMOVE_ME' in os.environ:
    DEBUG = True
  else:
    DEBUG = False

  # Get secret local settings from environment.
  SECRET_KEY = os.environ['SECRET_KEY']
  DB_USER = os.environ['DB_USER']
  DB_HOST = os.environ['DB_HOST']
  DB_PASSWORD = os.environ['DB_PASSWORD']

  import requests
  instance_metadata_url = 'http://169.254.169.254/latest/meta-data/iam/security-credentials/CrawlerEC2InstanceRole'
  _instance_metadata = requests.get(instance_metadata_url)

  DATABASES = {
    'default': {
      'ENGINE': 'django.db.backends.postgresql',
      'NAME': 'postgres',
      'USER': DB_USER,
      'PASSWORD': DB_PASSWORD,
      'HOST': DB_HOST,
      'PORT': '5432',
    }
  }

  DATABASES['default']['CONN_MAX_AGE'] = 3600

  ALLOWED_HOSTS = [
    # If curl-ing directly from inside the gunicorn container, bypassing nginx.
    'localhost',
    '127.0.0.1',
    # See nginx.conf for where we set this Host header.
    'snowchain.gunicorn.local',
  ]

  # # In AWS, nginx fronts Django via docker container link, which under the covers becomes a
  # # request to the instance's public hostname.
  # import requests
  # HOSTNAME = None
  # r = requests.get('curl http://169.254.169.254/latest/meta-data/public-hostname', timeout=0.01)
  # r.raise_for_status()
  # HOSTNAME = r.text
  # if HOSTNAME:
  #   ALLOWED_HOSTS.append(HOSTNAME)
