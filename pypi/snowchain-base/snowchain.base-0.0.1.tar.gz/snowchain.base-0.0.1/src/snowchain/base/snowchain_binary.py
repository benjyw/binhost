# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import argparse
import logging
import sys

import coloredlogs


class SnowchainBinary(object):
  """Provides useful shared functionality for our Python binaries.

  Extend this in your main module, implement callbacks as needed,
  and add the following boilerplate to make your module the entry point:

  if __name__ == '__main__':
    YourSnowchainBinarySubclass.start()

  The binary will exit with the exit code returned by your run() method.
  """
  @classmethod
  def add_arguments(cls, parser):
    """Override this to add arguments to the provided argparse.ArgumentParser."""
    pass

  def __init__(self, cmdline_args):
    """Override this to perform custom initialization.

    Your binary can access the cmdline args via the cmdline_args property.
    It is also free to initialize its own state from the cmdline_args param, and not use the
    self.cmdline_args property at all.  However your __init__ method must still call this one
    via super(YourSnowchainBinarySubclass, self).__init__(cmdline_args), to ensure initialization.
    """
    self._cmdline_args = cmdline_args
    self._enable_colors = not cmdline_args.no_colors

  @property
  def cmdline_args(self):
    return self._cmdline_args

  @property
  def enable_colors(self):
    return self._enable_colors

  def run(self):
    """Override this to execute your program logic."""
    raise NotImplementedError()

  @classmethod
  def start(cls):
    args = cls._get_args()
    logging.basicConfig(level=logging.INFO, format=cls._FORMAT)
    if not args.no_colors:
      coloredlogs.install(level=logging.DEBUG, fmt=cls._FORMAT, field_styles=cls._FIELD_STYLES)
    instance = cls(args)
    exit_code = instance.run()
    sys.exit(exit_code)

  _FORMAT = '%(asctime).19s %(levelname)-7s %(message)s'

  _FIELD_STYLES = {
    'levelname': {'color': 'cyan'},
    'asctime': {'color': 'green'}
  }

  @classmethod
  def _get_args(cls):
    parser = argparse.ArgumentParser(description='Diff two entries files.')
    parser.add_argument('--no-colors', action='store_true', help='Do not colorize console output.')
    cls.add_arguments(parser)
    return parser.parse_args()
