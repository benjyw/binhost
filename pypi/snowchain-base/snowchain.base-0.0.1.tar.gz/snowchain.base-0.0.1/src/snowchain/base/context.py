# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import os
import re
from contextlib import contextmanager

import pkg_resources
import pystache
from attrdict import AttrMap

from snowchain.base.fileutil import safe_mkdir, temporary_dir


class Context(AttrMap):
  """A context for some set of operations that requires input values.

  A context is a collection of key=value properties, typically read by exec'ing context files.
  The values may themselves reference other keys as keyword args (e.g., "Hello, {foo}!").
  So this class includes functionality to recursively perform keyword arg substitution.

  foo = 'World'
  bar = 'Hello, {foo}!'
  baz = 'Here is a sentence: "{bar}"'

  Then baz will render as 'Here is a sentence: "Hello, World!"'.

  The fully-substituted context can then be used to provide values, to render mustache
  template files, etc.
  """
  class Error(Exception):
    pass

  @classmethod
  def create(cls, context_data):
    def maybe_format(v):
      if isinstance(v, (str, unicode)):
        return v.format(**context_data)
      else:
        return v

    # Format each value against the current key-values, repeating until quiescence.
    next_context_data = {}
    while True:
      for k in context_data.keys():
        next_context_data[k] = maybe_format(context_data[k])
      if context_data == next_context_data:
        break  # We've achieved quiescence, so all references have been substituted.
      context_data = next_context_data
      next_context_data = {}
    return cls(context_data)

  @contextmanager
  def _workdir(self):
    with temporary_dir(cleanup=self.cleanup) as workdir:
      if not self.cleanup:
        print('Created workdir at {}'.format(workdir))
      yield workdir

  def render_all_files_under_dir(self, src_dir, dst_dir, extra_vars=None, relpath_regex=None):
    pattern_re = re.compile(relpath_regex or r'.*')
    for src_subdir, dirnames, filenames in os.walk(src_dir):
      dst_subdir = os.path.join(dst_dir, os.path.relpath(src_subdir, src_dir))
      safe_mkdir(dst_subdir)
      for filename in filenames:
        src = os.path.join(src_subdir, filename)
        dst = os.path.join(dst_subdir, filename)
        if pattern_re.match(src):
          self.render_file(src, extra_vars=extra_vars, dst=dst)

  def render_file(self, template_file, extra_vars=None, dst=None):
    """Returns the rendered text if dst is None, or dst otherwise."""
    with open(template_file) as fp:
      return self.render_template(fp.read(), extra_vars=extra_vars, dst=dst)

  @contextmanager
  def render_resource_into_tmpfile(self, module_name, basename, extra_vars=None):
    with self._workdir() as workdir:
      yield self.render_resource(module_name, basename, extra_vars=extra_vars, dst_dir=workdir)

  def render_resource(self, module_name, basename, extra_vars=None, dst_dir=None):
    """Returns the rendered text if dst_dir is None, or the path to the rendered resource otherwise."""
    template = pkg_resources.resource_string(module_name, basename)
    dst = os.path.join(dst_dir, basename) if dst_dir else None
    rendered_text = self.render_template(template, extra_vars=extra_vars, dst=dst)
    return dst or rendered_text

  def render_template(self, template, extra_vars=None, dst=None):
    """Returns the rendered text if dst is None, or dst otherwise."""
    renderer = pystache.Renderer()
    ret = renderer.render(template, self, extra_vars)
    if dst:
      if os.path.exists(dst):
        raise self.Error('Cannot overwrite existing file {}.'.format(dst))
      with open(dst, 'w') as fp:
        fp.write(ret)
      if not self.cleanup:
        print('Rendered file to {}'.format(dst))
    return dst or ret
