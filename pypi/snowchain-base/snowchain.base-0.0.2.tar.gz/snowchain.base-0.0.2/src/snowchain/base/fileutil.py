# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import errno
import os
import shutil
from contextlib import contextmanager
from tempfile import mkdtemp


def safe_mkdir(path):
  """Create a directory (and all intermediate directories) without erroring if it already exists."""
  try:
    os.makedirs(path)
  except OSError as e:
    if e.errno != errno.EEXIST:
      raise


@contextmanager
def temporary_dir(suffix='', prefix='tmp', dir=None, cleanup=True):
  """Yield a temporary directory in a context and clean it up when the context exits."""
  d = None
  try:
    d = mkdtemp(suffix, prefix, dir)
    yield d
  finally:
    if d and cleanup:
      shutil.rmtree(d)
