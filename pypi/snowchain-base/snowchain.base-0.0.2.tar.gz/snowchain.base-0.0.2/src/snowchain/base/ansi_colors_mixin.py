# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

from colors import (black, blink, blink2, blue, bold, concealed, crossed, cyan, faint,
                    green, italic, magenta, negative, red, underline, white, yellow)


class ANSIColorsMixin(object):
  @property
  def enable_colors(self):
    """Override in a subclass to enable or disable ANSI colors."""
    return True

  def black(self, s):     return self._maybe(black, s)
  def blink(self, s):     return self._maybe(blink, s)
  def blink2(self, s):    return self._maybe(blink2, s)
  def blue(self, s):      return self._maybe(blue, s)
  def bold(self, s):      return self._maybe(bold, s)
  def concealed(self, s): return self._maybe(concealed, s)
  def crossed(self, s):   return self._maybe(crossed, s)
  def cyan(self, s):      return self._maybe(cyan, s)
  def faint(self, s):     return self._maybe(faint, s)
  def green(self, s):     return self._maybe(green, s)
  def italic(self, s):    return self._maybe(italic, s)
  def magenta(self, s):   return self._maybe(magenta, s)
  def negative(self, s):  return self._maybe(negative, s)
  def red(self, s):       return self._maybe(red, s)
  def underline(self, s): return self._maybe(underline, s)
  def yellow(self, s):    return self._maybe(yellow, s)
  def white(self, s):     return self._maybe(white, s)

  def _maybe(self, color, s):
    return color(s) if self.enable_colors else s
