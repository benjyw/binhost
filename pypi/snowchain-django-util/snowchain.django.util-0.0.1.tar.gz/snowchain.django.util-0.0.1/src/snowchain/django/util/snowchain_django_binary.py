# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import os
import sys


class SnowchainDjangoBinary(object):
  def __init__(self, main_app_package):
    self._main_app_package = main_app_package

  def manage(self):
    self._set_settings()
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)

  def get_wsgi_application(self):
    self._set_settings()
    from django.core.wsgi import get_wsgi_application
    return get_wsgi_application()

  def _set_settings(self):
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', self._get_settings_module_name())

  def _get_settings_module_name(self):
    return '{}.settings'.format(self._main_app_package)
