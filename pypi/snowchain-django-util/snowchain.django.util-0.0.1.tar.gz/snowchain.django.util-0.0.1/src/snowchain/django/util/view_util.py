# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import datetime

from django.contrib.auth.mixins import UserPassesTestMixin
from django.core.serializers.json import DjangoJSONEncoder
from django.http import JsonResponse
from django.views import View


class SuperuserOnlyMixin(UserPassesTestMixin):
  """Subclass views will only be accessible to superusers."""
  # Subclasses must provide this as an instance property.
  request = None

  def test_func(self):
    return self.request.user.is_superuser


class AjaxView(View):
  returns_list = False

  class JsonEncoder(DjangoJSONEncoder):
    def default(self, o):
      # See "Date Time String Format" in the ECMA-262 specification.
      if isinstance(o, datetime.datetime):
        # Convert to ISO 8601 date format (parseable by JS's Date.parse()).
        return o.isoformat()
      return super(AjaxView.JsonEncoder, self).default(o)

  def get(self, request, *args, **kwargs):
    data = self.get_ajax_data()
    return JsonResponse(data, encoder=self.JsonEncoder, safe=not self.returns_list)

  def get_ajax_data(self):
    """Subclasses implement this to return a JSON-encodable data structure."""
    raise NotImplementedError()
