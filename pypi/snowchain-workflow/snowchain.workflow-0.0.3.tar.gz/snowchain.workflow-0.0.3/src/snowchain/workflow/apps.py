# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

from django.apps import AppConfig
from django.contrib.postgres.search import SearchVector
from django.db.models import F, Func, Value
from django.db.models.signals import post_save, pre_save


def set_work_unit_creator(sender, instance, **kwargs):
  # Local import, so we don't try to indirectly import models during app setup.
  from snowchain.workflow.work_executor import WorkExecutor
  if instance.creator_id is None:
    instance.creator_id = WorkExecutor.get_calling_context()[1]


# Note that Django doesn't allow joins in an update, so we have to use this post_save
# annotation trick to set the search_vector to include fields from other models.

def _using_postgresql():
  from django.conf import settings
  return settings.DATABASES['default']['ENGINE'] in ['django.db.backends.postgresql',
                                                     'django.db.backends.postgresql_psycopg2']


# We know that WorkUnit instances are never bulk-created (multi-table models don't support it),
# so the signal is always triggered.
def update_workunit_search_vector(sender, instance, created, **kwargs):
  if not _using_postgresql():
    return
  # We know that these fields never change, so we only need to update on creation.
  if created:
    annotated_instance = sender.objects.filter(pk=instance.pk).annotate(
      document=SearchVector(
        'polymorphic_ctype__model',
        'description',
        Func(F('description'), Value('/'), Value(' '), function='replace')
      )).get()
    instance.search_vector = annotated_instance.document
    instance.save(update_fields=['search_vector'])


# We know that WorkExceptionLog instances are never bulk-created, so the signal is always triggered.
def update_workexception_search_vector(sender, instance, created, **kwargs):
  if not _using_postgresql():
    return
  # We know that these fields never change, so we only need to update on creation.
  if created:
    annotated_instance = sender.objects.filter(pk=instance.pk).annotate(
      document=SearchVector(
        'message',
        Func(F('message'), Value('/'), Value(' '), function='replace'),
        'work_unit__polymorphic_ctype__model',
        'work_unit__description',
        Func(F('work_unit__description'), Value('/'), Value(' '), function='replace'),
      )).get()
    instance.search_vector = annotated_instance.document
    instance.save(update_fields=['search_vector'])


def _register_leaf_subclasses(cls):
  if cls.__subclasses__():
    for subcls in cls.__subclasses__():
      _register_leaf_subclasses(subcls)
  else:
    pre_save.connect(set_work_unit_creator, sender=cls)
    post_save.connect(update_workunit_search_vector, sender=cls)


class WorkflowAppConfig(AppConfig):
  name = 'snowchain.workflow'
  verbose_name = 'Workflow System'

  def ready(self):
    from snowchain.workflow.models import WorkExceptionLog, WorkUnit
    post_save.connect(update_workexception_search_vector, sender=WorkExceptionLog)
    _register_leaf_subclasses(WorkUnit)
