# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

from django.db.models import Count, Q

from snowchain.workflow.models import WorkUnit


def get_work_status(lower_bound):
  """Retrieve stats on the status of the various work units.

  Returns a triple (success, pending, unavailable) with stats for work units in
  each of those three states.

  Each member of the triple is a dict of
  work unit type name -> number of work units of that type in the given state.
  """

  def mk_queryset():
    return WorkUnit.objects.values('polymorphic_ctype__model').annotate(count=Count('id'))

  def gen_result(qs):
    counts_per_model_type = {}
    for wu_count in sorted(qs, key=lambda x: x['polymorphic_ctype__model']):
      counts_per_model_type[wu_count['polymorphic_ctype__model']] = wu_count['count']
    return counts_per_model_type

  success_qs = mk_queryset().filter(last_success__gt=lower_bound)

  pending_qs = mk_queryset().filter(last_success__lte=lower_bound, feasible=True)

  unavailable_qs = mk_queryset().filter(last_success__lte=lower_bound, feasible=False)

  return gen_result(success_qs), gen_result(pending_qs), gen_result(unavailable_qs)
