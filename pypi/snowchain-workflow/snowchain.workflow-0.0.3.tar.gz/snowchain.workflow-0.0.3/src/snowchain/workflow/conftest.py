# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

from django.conf import settings


def pytest_cmdline_preparse(args):
  args[:] = args + ['--nomigrations']


def pytest_configure():
  settings.configure(
    SNOWCHAIN_ENV = 'snowchain_test',
    SECRET_KEY = 'TEST_SECRET_KEY',
    TIME_ZONE = 'UTC',
    USE_TZ = True,
    DATABASES = {
      'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': '.snowchain_test.sqlite3',
      }
    },
    INSTALLED_APPS = (
      'django.contrib.auth',
      'django.contrib.contenttypes',
      'django.contrib.messages',
      'django.contrib.sessions',
      'django.contrib.staticfiles',
      'polymorphic',
      'snowchain.django.site',
      'snowchain.workflow.apps.WorkflowAppConfig',
    ),
  )
