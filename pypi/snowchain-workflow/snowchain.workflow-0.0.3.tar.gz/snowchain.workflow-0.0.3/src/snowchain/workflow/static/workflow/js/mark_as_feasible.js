var snowchain = snowchain || {};

snowchain.workflow = snowchain.workflow || {};

snowchain.workflow.initMarkAsFeasible = function(clickTargetSelector, getPks, onSuccess) {
  $(clickTargetSelector).on('click', function(evt) {
    var pks = getPks();
    $.ajax(snowchain.workflow._markSelectedUrl, {
      method: 'POST',
      data: {
        'pks': pks
      },
      success: function(data, textStatus, jqXHR) {
        if (jqXHR.status == 200) {
          $.each(pks, function(i, pk) {
            $('.feasibility-icon-' + pk).removeClass('infeasible-icon').addClass('feasible-icon');
          });
        }
        if (onSuccess !== undefined) {
          onSuccess();
        }
      }
    });
    evt.preventDefault();
    return false;
  }).mouseup(function() { $(this).blur(); });
};

snowchain.workflow.initMarkAsFeasibleLink = function(clickTargetSelector, pk) {
  snowchain.workflow.initMarkAsFeasible(clickTargetSelector,
      function() { return [pk]; },
      function() { $(clickTargetSelector).hide(); });
};

snowchain.workflow.setMarkSelectedUrl = function(url) {
  snowchain.workflow._markSelectedUrl = url;
};
