# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)


class WorkException(Exception):
  """An exception indicating failure to process a unit of work."""

  # Indicates an event that may be transient, so the work can be retried later.
  TRANSIENT = 'TRANSIENT'

  # Indicates a permanent error, so the work should not be retried later (at least until
  # the cause of the error has been dealt with somehow).
  PERMANENT = 'PERMANENT'

  ALLOWED_CATEGORIES = [TRANSIENT, PERMANENT]

  def __init__(self, category, msg):
    super(WorkException, self).__init__('{}: {}'.format(category, msg))
    if category not in self.ALLOWED_CATEGORIES:
      raise RuntimeError('Invalid type: {}'.format(category))
    self._category = category

  @property
  def category(self):
    return self._category


class FatalError(Exception):
  """A logic error indicating that the work loop should terminate."""
  pass
