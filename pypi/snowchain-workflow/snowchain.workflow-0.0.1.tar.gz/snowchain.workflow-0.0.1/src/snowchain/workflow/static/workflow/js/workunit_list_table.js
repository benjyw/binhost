var snowchain = snowchain || {};

snowchain.workflow = snowchain.workflow || {};

// tpl should be a url in which XXXXX should be substituted for row.id.
snowchain.workflow.setWorkunitStatusLinkTemplate = function(tpl) {
  snowchain.workflow._workunitStatusLinkTemplate = tpl;
};

snowchain.workflow._mavenUrlPrefix = 'https://repo1.maven.org/maven2/';

snowchain.workflow._getWorkunitStatusLink = function(anchorTxt, workunitId) {
  if (snowchain.workflow._workunitStatusLinkTemplate) {
    var anchorTxtAbbrev = _.startsWith(anchorTxt, snowchain.workflow._mavenUrlPrefix) ?
        anchorTxt.substring(snowchain.workflow._mavenUrlPrefix.length) : anchorTxt;
    var url = snowchain.workflow._workunitStatusLinkTemplate.replace('XXXXX', workunitId);
    return '<a href="' + url + '" data-toggle="popover" data-trigger="hover" data-placement="bottom" ' +
        'data-content="' + anchorTxt + '">' + anchorTxtAbbrev + '</a>'
  }
  return anchorTxt;
};

snowchain.workflow._feasiblityIcon = function(val, row) {
  var cls;
  if (val) {
    cls = 'feasible-icon';
  } else {
    cls = 'infeasible-icon';
  }
  var work_unit_id = _.get(row, 'work_unit_id', row.id);
  return '<span class="feasibility-icon feasibility-icon-' + work_unit_id + ' ' + cls + '"></span>';
};

snowchain.workflow.initWorkunitListTable = function(selector, dataUrl, pk, singleton, withLeaseInfo) {
  function workunitStatusLink(val, row) {
    return '<div>' + snowchain.workflow._getWorkunitStatusLink(val, row.id) + '</div>';
  }

  function colorLastSuccess(val, row) {
    cls = '';
    if (!moment(row.last_attempt).isSame(moment(0))) {
      cls = (row.last_attempt === row.last_success) ? 'success' : 'warning';
    }
    return {
      classes: cls
    }
  }

  function seconds(val) {
    return '' + val + 's'
  }

  var tableId = selector.startsWith('#') ? selector.substring(1) : selector;
  var customToolbarClass = tableId + '-custom-toolbar';
  var customToolbar = $(selector).before(
      '<div class="' + customToolbarClass + '">' +
      '<button class="btn btn-default mark-selected-as-feasible-btn disabled" href="#">Mark as feasible</button>' +
      '</div>');

  var columns = [
    {
      title: 'Selected',
      field: 'selected',
      align: 'left',
      valign: 'middle',
      checkbox: true
    }, {
      title: 'ID',
      field: 'id',
      align: 'left',
      valign: 'middle',
      formatter: workunitStatusLink
    },  {
      title: 'WorkUnit Type',
      field: 'type',
      align: 'left',
      valign: 'middle',
      sortable: true
    }, {
      title: 'Description',
      field: 'description',
      align: 'left',
      valign: 'middle',
      sortable: true,
      formatter: workunitStatusLink,
      cellStyle: { classes: 'workunit-list-table-description' }
    }, {
      title: 'Feasible',
      field: 'feasible',
      align: 'left',
      valign: 'middle',
      sortable: true,
      formatter: snowchain.workflow._feasiblityIcon
    }, {
      title: 'Last attempt',
      field: 'last_attempt',
      align: 'left',
      valign: 'middle',
      sortable: true,
      formatter: snowchain.site.util.shortenDateTime
    }, {
      title: 'Last success',
      field: 'last_success',
      align: 'left',
      valign: 'middle',
      sortable: true,
      formatter: snowchain.site.util.shortenDateTime,
      cellStyle: colorLastSuccess
    }];
    if (withLeaseInfo) {
      columns.push({
        title: 'Node',
        field: 'node',
        align: 'left',
        valign: 'middle',
        sortable: true
      });
      columns.push({
        title: 'Lease',
        field: 'leased_remaining',
        align: 'left',
        valign: 'middle',
        sortable: true,
        formatter: seconds
      });
    }

  var tableOptions = {
    url: dataUrl,
    showRefresh: !singleton,
    showToggle: !singleton,
    showColumns: !singleton,
    search: !singleton,
    pagination: !singleton,
    sidePagination: 'server',
     selectItemName: 'selected',
    clickToSelect: true,
    maintainSelected: false,
    toolbarAlign: 'left',
    toolbar: '.' + customToolbarClass,

    idField: 'id',
    columns: columns,
    onPostBody: function() {
      $(selector + ' [data-toggle="popover"]').popover();
    }
  };
  if (pk !== undefined) {
    tableOptions['queryParams'] = function(params) {
      params['pk'] = pk;
      return params;
    };
  }

  snowchain.table.initTable(selector, tableOptions);
  var tableElem = $(selector);
  var markSelectedAsFeasibleBtnSelector = '.' + customToolbarClass + ' .mark-selected-as-feasible-btn';
  function getSelectedPks() {
    return $.map(tableElem.bootstrapTable('getAllSelections'), function(row) { return row.id; });
  }
  snowchain.workflow.initMarkAsFeasible(markSelectedAsFeasibleBtnSelector, getSelectedPks,
      function() {
        tableElem.bootstrapTable('uncheckAll');
        tableElem.find('tr').removeClass('selected');
        $(markSelectedAsFeasibleBtnSelector).addClass('disabled');
      });

  tableElem.on('check.bs.table uncheck.bs.table', function() {
    $(markSelectedAsFeasibleBtnSelector).toggleClass('disabled', (getSelectedPks().length === 0));
  });
};

// tpl should be a url in which XXXXX should be substituted for row.id.
snowchain.workflow.setWorkExceptionLinkTemplate = function(tpl) {
  snowchain.workflow._workExceptionLinkTemplate = tpl;
};

snowchain.workflow.initWorkExceptionLogTable = function(selector, dataUrl, workunitId) {
  function workExceptionDetailLink(val, row) {
    if (snowchain.workflow._workExceptionLinkTemplate) {
      var url = snowchain.workflow._workExceptionLinkTemplate.replace('XXXXX', row.id);
      return '<a href="' + url + '">' + val + '</a>'
    }
    return val;
  }

  function workunitStatusLink(val, row) {
    return snowchain.workflow._getWorkunitStatusLink(val, row.work_unit_id);
  }

  var inSingleWorkUnit = workunitId !== undefined;

  var tableId = selector.startsWith('#') ? selector.substring(1) : selector;
  var customToolbarClass = tableId + '-custom-toolbar';
  var customToolbar = $(selector).before(
      '<div class="' + customToolbarClass + '">' +
      '<button class="btn btn-default mark-selected-as-feasible-btn disabled" href="#">Mark work unit as feasible</button>' +
      '</div>');

  var tableOptions = {
    url: dataUrl,
    showRefresh: !inSingleWorkUnit,
    showToggle: !inSingleWorkUnit,
    showColumns: !inSingleWorkUnit,
    search: !inSingleWorkUnit,
    pagination: !inSingleWorkUnit,
    sidePagination: 'server',
    selectItemName: 'selected',
    clickToSelect: true,
    maintainSelected: false,
    toolbarAlign: 'left',
    toolbar: '.' + customToolbarClass,

    selectItemName: 'selected',
    clickToSelect: true,

    toolbarAlign: 'left',
    toolbar: '.' + customToolbarClass,

    idField: 'id',
    columns:
        [{
          title: 'Selected',
          field: 'selected',
          align: 'left',
          valign: 'middle',
          checkbox: true
        }, {
          title: 'ID',
          field: 'id',
          align: 'left',
          valign: 'top',
          formatter: workExceptionDetailLink
        }, {
          title: 'Timestamp',
          field: 'timestamp',
          align: 'left',
          valign: 'top',
          sortable: true,
          formatter: snowchain.site.util.shortenDateTime
        }, {
          title: 'Category',
          field: 'category',
          align: 'left',
          valign: 'top',
          sortable: true
        }, {
          title: 'Message',
          field: 'message',
          align: 'left',
          valign: 'top',
          sortable: true,
          formatter: workExceptionDetailLink
        }, {
          title: 'WorkUnit',
          field: 'work_unit',
          align: 'left',
          valign: 'top',
          sortable: true,
          formatter: workunitStatusLink
        }, {
          title: 'Feasible',
          field: 'work_unit_feasible',
          align: 'left',
          valign: 'middle',
          sortable: true,
          formatter: snowchain.workflow._feasiblityIcon
        }]
  };
  if (inSingleWorkUnit) {
    tableOptions['queryParams'] = function(params) {
      params['workunit_id'] = workunitId;
      return params;
    };
    // Don't show the WorkUnit column, since we're showing errors in the context of a single WorkUnit.
    tableOptions.columns.pop();
  }
  snowchain.table.initTable(selector, tableOptions);
  var markSelectedAsFeasibleBtnSelector = '.' + customToolbarClass + ' .mark-selected-as-feasible-btn';
  function getSelectedPks() {
    return $.map($(selector).bootstrapTable('getAllSelections'), function(row) { return row.work_unit_id; });
  }
  snowchain.workflow.initMarkAsFeasible(markSelectedAsFeasibleBtnSelector, getSelectedPks,
      function() {
        $(selector).bootstrapTable('uncheckAll');
        $(selector + ' tr').removeClass('selected');
        $(markSelectedAsFeasibleBtnSelector).addClass('disabled');
      });

  $(selector).on('check.bs.table uncheck.bs.table', function() {
    $(markSelectedAsFeasibleBtnSelector).toggleClass('disabled', (getSelectedPks().length == 0));
  });
};
