# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

from django.conf.urls import url

from snowchain.workflow import views

urlpatterns = [
  # WorkUnit-related views.
  url(r'^summary/$', views.WorkflowSummary.as_view(), name='summary'),
  url(r'^workunit/status/(?P<pk>\w+)/$', views.WorkUnitStatus.as_view(), name='workunit_status'),
  url(r'^workunit/ancestors/(?P<pk>\w+)/$', views.WorkUnitAncestors.as_view(), name='workunit_ancestors'),
  url(r'^workunit/descendants/(?P<pk>\w+)/$', views.WorkUnitDescendants.as_view(), name='workunit_descendants'),
  url(r'^workunit/requirements/$', views.WorkUnitRequirementsData.as_view(), name='workunit_requirements_data'),
  url(r'^workunit/required_by/$', views.WorkUnitRequiredByData.as_view(), name='workunit_required_by_data'),
  url(r'^workunit/created/$', views.WorkUnitCreatedData.as_view(), name='workunit_created_data'),
  url(r'^workunit/created_by/$', views.WorkUnitCreatedByData.as_view(), name='workunit_created_by_data'),
  url(r'^workunit/created_by_tree/$', views.WorkUnitDescendantTreeData.as_view(), name='workunit_created_by_tree_data'),
  url(r'^workunit/active/$', views.WorkUnitActiveData.as_view(), name='workunit_active_data'),
  url(r'^workunits/list/$', views.WorkUnitList.as_view(), name='workunit_list'),
  url(r'^workunits/list/data/$', views.WorkUnitListData.as_view(), name='workunit_list_data'),
  url(r'^workunit/mark_as_feasible/$', views.MarkAsFeasible.as_view(), name='mark_as_feasible'),

  # WorkException-related views.
  url(r'^workexception/(?P<pk>\w+)/$', views.WorkExceptionLogDetail.as_view(), name='workexceptionlog_detail'),
  url(r'^workexceptions/$', views.WorkExceptionLogView.as_view(), name='workexceptionlog_list'),
  url(r'^workexceptions/data/$', views.WorkExceptionLogData.as_view(), name='workexceptionlog_data'),
  url(r'^workexceptions/for/$', views.WorkExceptionsForWorkUnitData.as_view(), name='workexceptionsforworkunit_data'),
]
