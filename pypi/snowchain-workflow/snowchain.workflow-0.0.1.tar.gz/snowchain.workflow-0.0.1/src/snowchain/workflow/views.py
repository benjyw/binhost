# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import logging
from collections import defaultdict

from django.contrib.contenttypes.models import ContentType
from django.db.models import BooleanField, Case, Count, F, Q, Value, When
from django.http import HttpResponse
from django.utils import timezone
from django.views import View
from django.views.generic import DetailView, TemplateView

from snowchain.django.site.jinja2_environment import seconds_from_now
from snowchain.django.util.view_util import AjaxView, SuperuserOnlyMixin
from snowchain.workflow.models import UNIX_EPOCH, WorkExceptionLog, WorkUnit
from snowchain.workflow.work_dispatcher import WorkDispatcher

logger = logging.getLogger(__name__)


# Views for the workers themselves.

class WorkerStatusz(SuperuserOnlyMixin, TemplateView):
  template_name = 'workflow/worker_statusz.html'

  def get_queued_work_units(self):
    return WorkDispatcher.singleton.get_queued_work_units()


# Views for the admin server.

class WorkflowSummary(SuperuserOnlyMixin, TemplateView):
  template_name = 'workflow/summary.html'

  def counts(self):
    # Map of workunit type -> map from status to count.
    ret = defaultdict(lambda: defaultdict(int))

    qs = WorkUnit.objects.values(
      'polymorphic_ctype__model',
      'feasible',
      successful=Case(When(last_attempt__gt=UNIX_EPOCH, last_attempt=F('last_success'), then=Value(True)),
                      default=Value(False), output_field=BooleanField())
    ).annotate(count=Count('*'))

    for row in qs:
      if row['successful']:
        status = 'successful'
      elif not row['feasible']:
        status = 'infeasible'
      else:
        status = 'pending'
      ret[row['polymorphic_ctype__model']][status] += row['count']

    return ret


# WorkUnit views.


class WorkUnitList(SuperuserOnlyMixin, TemplateView):
  template_name = 'workflow/workunit_list.html'


class WorkUnitStatus(SuperuserOnlyMixin, DetailView):
  model = WorkUnit

  template_name = 'workflow/workunit_status.html'


class WorkUnitListDataBase(SuperuserOnlyMixin, AjaxView):
  def get_workunit_list_qs(self):
    raise NotImplementedError()

  def get_pk(self):
    pk_str = self.request.GET.get('pk')
    return None if pk_str is None else int(pk_str)

  def get_ajax_data(self):
    search = self.request.GET.get('search')
    offset = int(self.request.GET.get('offset', 0))
    limit = int(self.request.GET.get('limit', 25))
    sort = self.request.GET.get('sort', 'id')
    order = self.request.GET.get('order')

    if sort == 'type':
      sort_field = 'polymorphic_ctype__model'
    elif sort == 'leased_remaining':
      sort_field = 'leased_until'
    else:
      sort_field = sort
    if order == 'desc':
      sort_field = '-{}'.format(sort_field)

    workunits_qs = self.get_workunit_list_qs().non_polymorphic().select_related('polymorphic_ctype__model')
    if search:
      workunits_qs = workunits_qs.filter(search_vector=search)

    ctypes = {ctype.id: ctype.model for ctype in ContentType.objects.all()}
    workunit_dicts = workunits_qs.order_by(sort_field).values()[offset:offset+limit]
    for wd in workunit_dicts:
      wd['type'] = ctypes.get(wd.get('polymorphic_ctype_id'))
      wd['leased_remaining'] = seconds_from_now(wd['leased_until'])

    rows = list(workunit_dicts)
    if offset == 0 and len(rows) < limit:
      total = len(rows)
      # This spares us the extra query for the count, and also mitigates the weirdness of small results displaying
      # a count that doesn't match the number of rows the user actually sees, due to changes in state between
      # the the two queries.
    else:
      total = workunits_qs.count()

    ret = {
      'rows': rows,
      'total': total
    }
    return ret


class WorkUnitListData(WorkUnitListDataBase):
  """All WorkUnits."""
  def get_workunit_list_qs(self):
    return WorkUnit.objects.all()


class WorkUnitRequirementsData(WorkUnitListDataBase):
  """WorkUnits that the specified WorkUnit requires."""
  def get_workunit_list_qs(self):
    return WorkUnit.objects.get(pk=self.get_pk()).requirements.all()


class WorkUnitRequiredByData(WorkUnitListDataBase):
  """WorkUnits that require the specified WorkUnit."""
  def get_workunit_list_qs(self):
    return WorkUnit.objects.get(pk=self.get_pk()).required_by.all()


class WorkUnitCreatedData(WorkUnitListDataBase):
  """WorkUnits created by the specified WorkUnit."""
  def get_workunit_list_qs(self):
    return WorkUnit.objects.get(pk=self.get_pk()).created.all()


class WorkUnitCreatedByData(WorkUnitListDataBase):
  """The WorkUnit that created the specified WorkUnit."""
  def get_workunit_list_qs(self):
    wu = WorkUnit.objects.get(pk=self.get_pk())
    return WorkUnit.objects.filter(id=wu.creator_id)


class WorkUnitActiveData(WorkUnitListDataBase):
  """WorkUnits currently under lease."""
  def get_workunit_list_qs(self):
    return WorkUnit.objects.exclude(lease_holder='').filter(Q(leased_until__gte=timezone.now()))


class WorkUnitDescendantTreeData(SuperuserOnlyMixin, AjaxView):
  def get_ajax_data(self):
    def mk_tree_node(wu, children):
      # `children` can be a boolean (if True, this node has children) or a list of the actual children.
      return {
        'id': wu.id,
        'text': str(wu),
        'icon': False,
        'children': children,
        'state': { 'opened': children and children != True },
        'status_url': wu.get_status_url()
      }

    pk = int(self.request.GET.get('pk'))
    workunit = WorkUnit.objects.get(pk=pk)
    child_workunits = list(WorkUnit.objects.filter(creator=workunit))
    if child_workunits:
      child_ids = [c.id for c in child_workunits]
      children_with_children = set(WorkUnit.objects.filter(creator_id__in=child_ids)
                                   .values_list('creator_id', flat=True).distinct())
      child_tree_nodes = [mk_tree_node(c, c.id in children_with_children) for c in child_workunits]
    else:
      child_tree_nodes = False
    return mk_tree_node(workunit, child_tree_nodes)


class WorkUnitAncestors(SuperuserOnlyMixin, DetailView):
  model = WorkUnit
  template_name = 'workflow/workunit_ancestors.html'

  def get_ancestors(self):
    ret = []
    self._recursive_get_ancestors(ret, self.object)
    return reversed(ret)

  def _recursive_get_ancestors(self, ret, wu):
    if wu is None:
      return
    ret.append(wu)
    self._recursive_get_ancestors(ret, wu.creator)


class WorkUnitDescendants(SuperuserOnlyMixin, DetailView):
  model = WorkUnit
  template_name = 'workflow/workunit_descendants.html'


class MarkAsFeasible(SuperuserOnlyMixin, View):
  def post(self, request, *args, **kwargs):
    pks = request.POST.getlist('pks[]')
    if pks:
      WorkUnit.objects.filter(id__in=pks).update(feasible=True)
    return HttpResponse('')


# WorkException views.


class WorkExceptionLogView(SuperuserOnlyMixin, TemplateView):
  template_name = 'workflow/workexceptionlog_list.html'


class WorkExceptionLogDetail(SuperuserOnlyMixin, DetailView):
  model = WorkExceptionLog


class WorkExceptionLogDataBase(SuperuserOnlyMixin, AjaxView):
  def get_workexception_list_qs(self):
    raise NotImplementedError()

  def get_workunit_id(self):
    workunit_id_str = self.request.GET.get('workunit_id')
    return None if workunit_id_str is None else int(workunit_id_str)

  def get_ajax_data(self):
    search = self.request.GET.get('search')
    offset = int(self.request.GET.get('offset', 0))
    limit = int(self.request.GET.get('limit', 25))
    sort = self.request.GET.get('sort', 'id')
    order = self.request.GET.get('order')
    if order == 'desc':
      sort = '-{}'.format(sort)

    workexceptions_qs = self.get_workexception_list_qs().prefetch_related('work_unit', 'work_unit__polymorphic_ctype')
    if search:
      workexceptions_qs = workexceptions_qs.filter(search_vector=search)
    total = workexceptions_qs.count()
    workexceptions = workexceptions_qs.order_by(sort)[offset:offset+limit]
    workexception_dicts = [
      {
        'id': we.id,
        'timestamp': we.timestamp,
        'category': we.category,
        'work_unit': '{} {}'.format(we.work_unit.polymorphic_ctype.model, we.work_unit.description),
        'work_unit_id': we.work_unit.id,
        'work_unit_feasible': we.work_unit.feasible,
        'message': we.message,
      }
      for we in workexceptions
    ]
    ret = {
      'total': total,
      'rows': list(workexception_dicts)
    }
    return ret


class WorkExceptionLogData(WorkExceptionLogDataBase):
  def get_workexception_list_qs(self):
    return WorkExceptionLog.objects.all()


class WorkExceptionsForWorkUnitData(WorkExceptionLogDataBase):
  def get_workexception_list_qs(self):
    wu = WorkUnit.objects.get(pk=self.get_workunit_id())
    return WorkExceptionLog.objects.filter(work_unit=wu)
