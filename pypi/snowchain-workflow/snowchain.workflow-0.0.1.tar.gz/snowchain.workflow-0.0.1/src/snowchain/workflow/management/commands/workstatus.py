# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import logging
from datetime import datetime

from django.core.management.base import BaseCommand
from django.utils import timezone

from snowchain.workflow.models import UNIX_EPOCH, WorkEpoch
from snowchain.workflow.work_status import get_work_status

logger = logging.getLogger(__name__)


def _underline(s, c='-'):
  """Underline string s with character c."""
  return s + '\n' + len(s.lstrip('\n')) * c


# Reminder that Django requires this class to be named 'Command'.
# The command name is the module name.
class Command(BaseCommand):
  help = 'Show current status of work system.'

  def add_arguments(self, parser):
    parser.add_argument(
      '--lower-bound',
      help='Evaluate work completion relative to this UTC timestamp (formatted as YYYY-MM-DD_hh:mm:ss).'
           'If unspecified, the most recent (completed or uncompleted) epoch is used.',
    )

  def handle(self, *args, **options):
    lower_bound = UNIX_EPOCH
    lower_bound_str = options.get('lower-bound')
    if lower_bound_str:
      lower_bound = datetime.strptime(
        lower_bound_str, '%Y-%m-%d_%H:%M:%S').replace(tzinfo=timezone.utc)
    else:
      try:
        lower_bound = WorkEpoch.objects.latest().lower_bound
      except WorkEpoch.DoesNotExist:
        logger.warning('No WorkEpoch found, and no --lower-bound specified, using the Unix epoch.')

    success, pending, unavailable = get_work_status(lower_bound)

    def print_stats(stats):
      for stat in sorted(stats.items()):
        print('{}: {}'.format(*stat))

    print(_underline('\nStatus relative to lower bound {}'.format(
      lower_bound.strftime('%Y-%m-%d %H:%M:%S %Z')), c='='))

    print(_underline('\nSucceeded'))
    print_stats(success)

    print(_underline('\nFeasible'))
    print_stats(pending)

    print(_underline('\nInfeasible'))
    print_stats(unavailable)

    print('')
