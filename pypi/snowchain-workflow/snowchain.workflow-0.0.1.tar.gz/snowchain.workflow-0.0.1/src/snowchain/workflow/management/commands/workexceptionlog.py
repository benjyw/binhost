# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import logging
import sys

from django.core.management.base import BaseCommand

from snowchain.workflow.error import WorkException
from snowchain.workflow.models import WorkExceptionLog

logger = logging.getLogger(__name__)


# Reminder that Django requires this class to be named 'Command'.
# The command name is the module name.
class Command(BaseCommand):
    help = 'Show recent work exceptions.'

    def add_arguments(self, parser):
      parser.add_argument(
          '-n', type=int, default=10,
          help='Show up to this many exceptions.',
      )
      parser.add_argument(
          '--show', choices=['transient', 'permanent', 'all'], default='all',
          help='Whether to show only transient errors, only permanent errors, or all errors.',
      )
      parser.add_argument(
          '--stacktrace-frames', type=int, default=0,
          help='Show up to this many stacktrace frames per exception.',
      )

    def handle(self, *args, **options):
      n = options['n']
      show = options['show']
      stacktrace_frames = options['stacktrace_frames']

      qs = WorkExceptionLog.objects.all()
      if show == 'warnings':
        qs = qs.filter(category=WorkException.TRANSIENT)
      elif show == 'errors':
        qs = qs.filter(category=WorkException.PERMANENT)
      for ex in qs.order_by('-timestamp')[0:n]:
        print('{}: {} ({})'.format(ex.category, ex.message, ex.work_unit))
        if stacktrace_frames > 0:
          lines = ex.stacktrace_frames(stacktrace_frames)
          sys.stdout.write('    |  ')
          print('\n    |'.join(lines))
