# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import logging
import time
import uuid
from datetime import datetime, timedelta

from django.db import transaction
from django.db.models import Min, Q
from django.utils import timezone
from six.moves import queue

from snowchain.base.snowchain_error import SnowchainError
from snowchain.workflow.error import FatalError
from snowchain.workflow.models import WorkUnit
from snowchain.workflow.work_executor import WorkExecutor
from snowchain.workflow.worker_thread import WorkerThread

logger = logging.getLogger(__name__)


# Dummy call before spawning any worker threads, as a workaround for https://bugs.python.org/issue7980.
# This way code in worker threads can call strptime without worrying about this.
datetime.strptime('', '')


class WorkDispatcher(object):
  """Dispatches work to workers."""

  singleton = None

  # If there's no work to do, sleep this long before looking for more.
  # Subclasses can override with a class or instance field.
  sleep_secs = 2

  def __init__(self, lower_bound, num_executor_threads=0, batch_size=0, work_types=None, node=''):
    """
    :param datetime.datetime lower_bound: Do all work that hasn't been done successfully since this timestamp.
    :param int num_executor_threads: Offload the actual work execution to this number of threads.
           by default spawns no threads and does all the work in the main thread.
    :param int batch_size: Fetch this many work units per batch.  Defaults to 2x the concurrency level
                           (2x num_executor_threads or 2 if no threads).
                           Larger numbers will mean fewer complex work-fetching db queries, and so
                           may decrease database load, at the expense of "tying up" more work units.
    :param work_types: A list of work types to fetch.  If unspecified, any type of work
                       will be eligible to be fetched.
    :param node: An optional identifier for the node this dispatcher is running on.
                 Useful for status reporting, but not required for correctness.
                 The meaning of "node" is unspecified, but useful examples include host:port, host.pid etc.
    """
    # Note that we want one singleton for all subclasses, so we reference the class explicitly.
    if WorkDispatcher.singleton is not None:
      raise SnowchainError('Cannot create more than one WorkDispatcher instance per process.')
    WorkDispatcher.singleton = self

    self._work_unit_to_worker_factory = {}  # Map from WorkUnit subclass to factory for Worker instance.
    self._lower_bound = lower_bound
    self._num_executor_threads = num_executor_threads
    self._batch_size = batch_size or 2 * self._num_executor_threads or 2
    self._work_types = work_types
    self._node = node
    # The main thread queries the db for work and enqueues it for the worker threads to dequeue.
    # The queue maxsize is selected to allow one work unit to wait in the pipeline per thread.
    # This means that threads (or at least the ones whose work is slower than the db query that
    # fetches the work) aren't idle waiting on the db query.
    # We don't want an arbitrarily large queue size though, as we hold the lease for everything
    # in the queue, so no other process can do that queued work.
    self._executor_queue = queue.Queue(maxsize=self._batch_size)

    for i in range(num_executor_threads):
      WorkerThread(self._executor_queue).start()

  def register_worker_cls(self, worker_cls):
    """Register a worker class that handles work units of a declared type.

    :param worker_cls: A subclass of `snowchain.workflow.worker.Worker` that defines
                       a class-level work_unit_cls property, which must be a subclass of
                       `snowchain.workflow.models.WorkUnit`.
                       This Worker subclass's `__init__` method must take a single argument
                       (the work unit instance).
    """
    if worker_cls.work_unit_cls is None:
      raise FatalError('Worker subclass {} does not specify a work_unit_cls'.format(worker_cls))
    self.register_worker_factory(worker_cls.work_unit_cls, worker_cls)

  def register_worker_factory(self, work_unit_cls, worker_factory):
    """Register a factory for creating worker instances to handle work units of the given type.

    :param work_unit_cls: A subclass of `snowchain.workflow.models.WorkUnit`.
    :param worker_factory: A callable that takes no arguments and returns an instance of
                           an appropriate subclass of `snowchain.workflow.worker.Worker`.
    """
    self._work_unit_to_worker_factory[work_unit_cls] = worker_factory

  def get_queued_work_units(self):
    """Returns the work units currently in the queue, waiting to be claimed by a worker thread."""
    # Note: relies on internals of Queue.
    with self._executor_queue.mutex:
      return [x.work_unit for x in self._executor_queue.queue]

  def work_loop(self):
    """Main work loop."""
    while True:
      self.loop_while_work_exists()
      logger.debug('No work to do. Sleeping for {} seconds.'.format(self.sleep_secs))
      time.sleep(self.sleep_secs)

  def loop_while_work_exists(self):
    """Do all work that can currently be done."""
    while True:
      if not self._process_one_work_batch():
        # We get here when there's no more work in the db to enqueue.
        # Wait until all the workers are idle.
        self._executor_queue.join()
        if not self._process_one_work_batch():
          # All workers are idle and there's still no work in the db, so nothing
          # in this process can create new work.  Therefore we return and let our
          # caller decide what to do.  E.g., in a test this means we're done, and in
          # production we can sleep for a short time before checking if any other
          # processes have created work for us to do.
          break

  def _process_one_work_batch(self):
    """Fetch and process a work batch.

    If we're in single-thread mode, executes the work synchronously in the calling thread.
    Otherwise enqueues the work, to be executed by worker threads.

    :return bool: False if there was no work to do, True otherwise.
    """
    executors = self._fetch_one_work_batch()
    if not executors:
      return False  # No work to do.

    if self._num_executor_threads == 0:
      # No worker threads, so execute the work units synchronously in the main thread.
      for executor in executors:
        executor.execute()
    else:
      # Enqueue a batch of work for the worker threads to execute.
      for executor in executors:
        # If the queue is full, put() will block until a slot opens up.
        self._executor_queue.put(executor)

    return True

  def _fetch_one_work_batch(self):
    """Fetches a batch of work from the database.

    :return: A list of WorkExecutor instances ready to be executed.  An empty list indicates
             that there's no work currently eligible to be performed.
    """
    executors = []
    now = timezone.now()
    with transaction.atomic():
      qs = self._get_queryset(now)
      work_units = list(qs)  # list() evaluates the QuerySet, causing the database roundtrip.
      for work_unit in work_units:
        worker = self._get_worker(work_unit)
        # Note that if lease_holder is currently set to the uuid of some other worker, then that
        # worker's lease has expired, so overwrite, preventing that worker from committing.
        work_unit.leased_until = now + timedelta(seconds=worker.lease_secs())
        work_unit.lease_holder = str(uuid.uuid1())
        work_unit.node = self._node
        work_unit.last_attempt = now
        work_unit.save()
        executors.append(WorkExecutor(work_unit, worker))
    return executors

  def _get_worker(self, work_unit):
    if work_unit is None:
      return None
    worker_cls = self._work_unit_to_worker_factory.get(type(work_unit))
    if worker_cls is None:
      raise FatalError('No Worker subclass registered for work unit of type {}'.format(type(work_unit)))
    return worker_cls()

  def _get_queryset(self, now):
    """Returns a QuerySet suitable for fetching available work units.

    The queryset will return up to num_executor_threads work units (or a single work unit if
    we're in single-thread mode).

    A work unit is available if it hasn't succeeded since our lower bound,
    it's not blocked on any requirements, and its lease isn't held.

    :param now: The current timestamp, for the purpose of lease comparison.
    :return: A QuerySet suitable for fetching available work units of the appropriate type.
    """
    # This queryset is a bit of a monster, but hopefully the comments below clarify each clause.
    # Postgres doesn't support FOR UPDATE locking on queries with GROUP BY.  So we have an inner
    # query (that uses GROUP BY) for selecting the ids of the work units we care about, and an
    # outer query that fetches full WorkUnit instances with the ids from the inner query,
    # and locks them using FOR UPDATE.

    # First restrict by type, if asked to do so.
    if self._work_types:
      inner_qs = reduce(lambda x, y: x | y,
                        map(lambda wt: WorkUnit.objects.instance_of(wt), self._work_types))
    else:
      inner_qs = WorkUnit.objects

    # Now add the other filters.
    inner_qs = self._restrict_to_available_work(inner_qs, now).only(
      'id'
    ).annotate(
        # For each work unit, find the earliest successful completion time of any requirement.
        req_last_success=Min('requirements__last_success')
    ).filter(
        # Only consider work units with no requirements, or those for which the earliest
        # successful completion time of any requirement is later than our lower bound
        # (implying that all requirements have completed successfully since that timestamp).
        Q(req_last_success__isnull=True) | Q(req_last_success__gt=self._lower_bound)
    ).order_by(
        # Try staler/older work first (we assume that ids are assigned in increasing order).
        # This doesn't actually matter for correctness, but is useful in tests.
        # Note that this means that a work unit that cannot succeed but also doesn't fail permanently
        # (so the system thinks it can be retried) will spin forever. If we have N worker processes
        # and N such work units then the entire system will stall.  However stalls are always a
        # possibility anyway when there are dependencies between work units, so we don't worry
        # about this case for now.
        'last_attempt', 'id'
    )

    inner_qs = inner_qs[:self._batch_size]

    # The outer query selects the WorkUnit instances whose ids are provided by the inner query.
    outer_qs = WorkUnit.objects.filter(id__in=inner_qs)

    # We must repeat this restriction:  Subqueries are not atomic with their outer queries,
    # so the following race condition is possible (and has actually been seen in production):
    #
    # 1) P1 and P2 both see W1 as available in the inner query.
    # 2) P1's outer query locks W1.
    # 3) P2's outer query blocks waiting for P1.
    # 4) P1 releases W1.
    # 5) P2's outer query sees that P1 updated W1, looks for the new version of W1,
    #    finds that it still satisifes the selection criteria (which is just that
    #    the id matches) and locks the row.
    #
    # Repeating the restriction ensures that P2's outer query will now reject W1 in step 5) above.
    # Note that we don't care about the requirements here - nothing P1 does can change that fact
    # that W1's requirements have been satisfied.
    outer_qs = self._restrict_to_available_work(outer_qs, now)

    # The select_for_update() means that the read query will also acquire an exclusive lock
    # on the resulting rows. Therefore any concurrent attempt to execute this query will block
    # until our transaction ends, thus guaranteeing that two concurrent processes will
    # never attempt to acquire the same work unit.
    # Note that we query on the WorkUnit base class, so that the FOR UPDATE lock will only apply
    # to that table, and not the subclass tables that django-polymorphic will query separately.
    outer_qs = outer_qs.select_for_update()

    return outer_qs

  def _restrict_to_available_work(self, qs, now):
    return qs.filter(
      # Restrict to available work units that aren't currently under lease, and haven't
      # been completed successfully since our lower bound.
      Q(leased_until__isnull=True) | Q(leased_until__lt=now),
      feasible=True,
      # Note that we use less-than-or-equals, so that work that last succeeded exactly on the
      # lower bound is considered stale.  This allows instances that don't care about epochs to
      # set the lower bound to the unix epoch (which is also the default value of last_success)
      # and thus ensure that the work gets done exactly once for all time.
      last_success__lte=self._lower_bound
    )
