# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import inspect
import logging
import sys
import traceback

from django.db import Error as DbError
from django.db import transaction

from snowchain.workflow.error import FatalError, WorkException
from snowchain.workflow.models import WorkExceptionLog, WorkUnit

logger = logging.getLogger(__name__)


class WorkExecutor(object):
  """Invokes a given worker on a given work unit.

  Invokes callbacks and updates database state based on the outcome of the work.
  """
  def __init__(self, work_unit, worker):
    self._work_unit = work_unit
    self._worker = worker

  @property
  def work_unit(self):
    return self._work_unit

  def execute(self):
    """Executes the work."""
    try:
      self._execute()
    except Exception as ex:
      # This indicates an error in the workunit state updating code itself (!).
      # We don't know what to do with this exception, so we err on the side of strictness and
      # make it PERMANENT, and make a best-effort attempt to mark the workunit as infeasible,
      # all this to alert admins that something requires attention.
      self._log_exception(self._work_unit, WorkException.PERMANENT, ex)
      try:
        WorkUnit.objects.filter(id=self._work_unit.id).update(
          feasible=False,
          leased_until=None,
          lease_holder='',
          node=''
        )
      except DbError:
        logger.error('Failed to set this workunit to infeasible: {}'.format(self._work_unit))

  def _execute(self):
    """Call do_work and handle the result (True/False/Exception).

    Handles exceptions raised in do_work() and in the on_success/on_reschedule/on_failure callbacks.
    """
    try:
      logger.info('Executing do_work() on {}'.format(self._work_unit))
      ret = self._worker.do_work(self._work_unit)
    except WorkException as ex:
      self._handle_exception(ex.category, ex)
      return
    except FatalError:
      raise
    except Exception as ex:
      # We assume that arbitrary exceptions mean a permanent error.
      self._handle_exception(WorkException.PERMANENT, ex)
      return
      # We don't catch BaseException, so critical exceptions like
      # SystemExit and KeyboardInterruptError will still exit the program.

    if ret is True:
      self._handle_success()
    elif ret is False:
      self._handle_reschedule()
    else:
      raise FatalError('{}.{}.do_work() must return True or False'.format(
        self._worker.__module__, self._worker.__class__.__name__))

  def _handle_success(self):
    def success_func(refetched_work_unit):
      logger.info('Executing on_success() on {}'.format(refetched_work_unit))
      self._worker.on_success(refetched_work_unit)
      refetched_work_unit.last_success = refetched_work_unit.last_attempt
    self._complete(success_func)

  def _handle_reschedule(self):
    def reschedule_func(refetched_work_unit):
      logger.info('Executing on_reschedule() on {}'.format(refetched_work_unit))
      # Return the return value of on_reschedule(), so _complete can use it to reschedule by time.
      return self._worker.on_reschedule(refetched_work_unit)
    self._complete(reschedule_func)

  def _handle_exception(self, category, e):
    def failure_func(refetched_work_unit):
      logger.info('Executing on_failure() on {}'.format(refetched_work_unit))
      self._worker.on_failure(refetched_work_unit)
      if category == WorkException.PERMANENT:
        refetched_work_unit.feasible = False
      self._log_exception(refetched_work_unit, category, e)
      # We don't re-raise, so that the outer loop can continue.
    self._complete(failure_func)

  def _complete(self, completion_func):
    """Call a completion function and update the work unit state, in a single transaction.

    First refetches and locks the work unit, to verify that the worker still holds the
    lease on the work unit.

    :param completion_func: A callable that takes a single argument- the refetched work unit.
      Called in the same transaction as the one that updates the work unit state.  May return
      a timestamp, in which case the lease will continue to be held until that timestamp
      (which may be before or after the original lease expiration).  Otherwise must return None,
      and the lease expires immediately.  This only matters when rescheduling: if the work
      succeeded or failed than the lease period is no longer consulted anyway.
    """
    with transaction.atomic():
      # Refetch the workunit, matching on the uuid, and locking the result.
      refetch = list(self._get_refetch_queryset())
      if refetch:
        # We still hold the lease on the work unit, so we're allowed to commit it.
        # If not, we return silently. The dispatcher will pick up the work unit and
        # attempt it again, since its lease has now expired.
        refetched_work_unit = refetch[0]
        refetched_work_unit.lease_holder = ''
        refetched_work_unit.node = ''
        try:
          # Inner tx is necessary, as we must catch exceptions outside an atomic block. See
          # https://docs.djangoproject.com/en/1.11/topics/db/transactions/#django.db.transaction.atomic.
          with transaction.atomic():
            refetched_work_unit.leased_until = self._execute_completion_func(completion_func, refetched_work_unit)
        except Exception as ex:
          # There was an error in the on_success/on_reschedule/on_failure callback.
          self._log_exception(self._work_unit, WorkException.PERMANENT, ex)
          refetched_work_unit.leased_until = None
          refetched_work_unit.feasible = False
        refetched_work_unit.save()
    self._worker.on_complete()

  def _execute_completion_func(self, completion_func, refetched_work_unit):
    return completion_func(refetched_work_unit)

  def _get_refetch_queryset(self):
    """Returns the QuerySet that refetches and locks a work unit if possible."""
    # Note that we query on the WorkUnit base class, so that the FOR UPDATE lock will only apply
    # to that table, and not the subclass tables that django-polymorphic will query separately.
    # Note also that we only fetch the WorkUnit if it's still feasible, so we don't try to commit work
    # that was marked as infeasible while we were working on it. This allows work to be canceled in mid-flight.
    # Note that we don't filter on leased_until: If no other worker has picked up this work yet, we may as
    # well commit our result, even if we overran our lease.
    return WorkUnit.objects.filter(
      id=self._work_unit.id,
      lease_holder=self._work_unit.lease_holder,
      feasible=True
    ).select_for_update()

  @classmethod
  def get_calling_context(cls):
    """Returns the workflow context in which this method was called.

    Returns the (Worker subclass, WorkUnit id) of the WorkExecutor instance that (indirectly)
    called this method.

    Allows us to populate a WorkUnit's "creator" field without plumbing the creating context through,
    when that WorkUnit is created inside an on_success/reschedule/failure callback.
    """
    for frame_record in inspect.stack():
      frame = frame_record[0]
      args, varargs, varkw, locls = inspect.getargvalues(frame)
      instance = locls.get('self')
      if type(instance) == cls:
        if inspect.getframeinfo(frame)[2] == cls._execute_completion_func.__name__:
          return type(instance._worker), instance._work_unit.id
    return None, None

  @classmethod
  def _log_exception(cls, work_unit, category, e):
    """Log an exception into the database."""
    stacktrace_str = cls._generate_exception_stacktrace()
    entry = WorkExceptionLog(category=category, work_unit=work_unit, message=str(e),
                             stacktrace=stacktrace_str)
    logger.error(entry)
    try:
      entry.save()
    except DbError:
      logger.error('Failed to log the following error in the WorkExceptionLog: {}'.format(entry))
      # Continue as usual: we don't want to stop processing work just because we failed to
      # log an error to the db.

  @staticmethod
  def _generate_exception_stacktrace():
    tb = sys.exc_info()[2]
    tb_lines = traceback.format_tb(tb)
    if any(['\t' in line for line in tb_lines]):
      stacktrace_str = 'No stacktrace captured due to embedded tabs'
    else:
      stacktrace_str = '\t'.join(traceback.format_tb(tb))
    return stacktrace_str

  def __str__(self):
    return str(self._work_unit)
