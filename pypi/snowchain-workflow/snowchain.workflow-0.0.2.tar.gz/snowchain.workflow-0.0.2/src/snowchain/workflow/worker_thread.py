# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

import logging
from threading import Thread

logger = logging.getLogger(__name__)


class WorkerThread(Thread):
  """A thread that consumes work from a queue and performs it."""
  def __init__(self, executor_queue):
    super(WorkerThread, self).__init__()
    # The name defaults to 'Thread-N' with N a small integer. We add a prefix
    # to more easily distinguish these threads in debug data.
    self.name = 'Worker{}'.format(self.name)
    self.daemon = True  # So the process exits when the main thread does.
    self._executor_queue = executor_queue

  def run(self):
    # Note that when the process exits this thread will exit abruptly, with no
    # chance to clean up after itself.  Since work is supposed to be committed
    # transactionally, this is fine.  In any case, we need to be robust to sudden
    # interruption (nothing can guarantee that it won't happen), so we might as
    # well make that the normal shutdown mode.
    while True:
      executor = self._executor_queue.get()  # Will block until work is available.
      try:
        logger.info('{} doing work: {}'.format(self.name, executor))
        executor.execute()
      finally:
        self._executor_queue.task_done()
