# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)

from datetime import datetime

from django.contrib.postgres.indexes import GinIndex
from django.contrib.postgres.search import SearchVectorField
from django.db.models import (CASCADE, BooleanField, CharField, DateTimeField,
                              ForeignKey, ManyToManyField, Model, TextField)
from django.urls import reverse
from django.utils import timezone
from polymorphic.models import PolymorphicModel

from snowchain.workflow.error import WorkException

UNIX_EPOCH = datetime.fromtimestamp(0, tz=timezone.utc)


class WorkUnit(PolymorphicModel):
  """A base class for work units.

  Note that this is a non-abstract Django model base class. In other words,
  WorkUnit has its own database table, and the tables for its subclasses have
  1:1 foreign keys back to this table.
  This allows a work dispatcher to claim arbitrary work types in a uniform way,
  while still attaching type-specific properties to each one.
  """

  class Meta:
    indexes = [
      GinIndex(fields=['search_vector'])
    ]

  # The WorkUnit that caused this one to be created, if any.
  # Deduced automatically if the creation is via save(), in a WorkExecutor on_* callback.
  # Must be set explicitly if using bulk-create, or creating outside a WorkExecutor callback.
  creator = ForeignKey('self', on_delete=CASCADE, related_name='created', null=True)

  # A useful human-readable description of this WorkUnit.
  description = CharField(max_length=256, db_index=True)

  # The last time a worker attempted this work unit.
  last_attempt = DateTimeField(db_index=True, default=UNIX_EPOCH)

  # A process marks successful completion of this work unit
  # by updating last_success to the current timestamp.
  last_success = DateTimeField(db_index=True, default=UNIX_EPOCH)

  # When the most recent lease on this work unit will expire (or has expired).
  # None if no worker has held a lease on this work unit since its last
  # successful completion.
  leased_until = DateTimeField(db_index=True, null=True, default=None)

  # A 36-byte uuid string (e.g., 'd3fa24dc-8a6a-11e6-8605-040ccee06e78') identifying
  # the worker that holds (or held) the most recent lease on this work unit.
  # A blank string if no worker has held a lease on this work unit since its last
  # successful completion.
  lease_holder = CharField(max_length=36, blank=True, default='')

  # Identifies the node currently executing this workunit, if any.
  # The meaning of "node" (machine, container, process, thread etc.), and the interpretation of this field,
  # are unspecified.  This field is optional; The workflow system  doesn't require it in order to function.
  # It's primarily used to provide information to admins when examining the state of a running workflow system.
  node = CharField(max_length=100, blank=True, default='')

  # If False, do not attempt to claim this work unit.
  # Used to mark work that should not or cannot succeed, at least until some external problem is fixed,
  # in which case this can be set back to True to trigger another attempt.
  feasible = BooleanField(default=True)

  # Other work that must be completed before this work can be attempted.
  requirements = ManyToManyField('self', symmetrical=False, through='WorkUnitRequirement',
                                 related_name='required_by', blank=True)

  search_vector = SearchVectorField(null=True)

  def has_ever_succeeded(self):
    return self.last_success > UNIX_EPOCH

  def get_status_url(self):
    return reverse('workflow:workunit_status', kwargs={'pk': self.pk})

  def get_absolute_url(self):
    """Subclasses can override to customize the detail view in the workflow status app."""
    return None

  def __str__(self):
    return '{} {} ({})'.format(self.polymorphic_ctype.model, self.id, self.description)

  def __repr__(self):
    return '{} {} ({})'.format(self.polymorphic_ctype, self.id, self.description)


class WorkUnitRequirement(Model):
  """A work unit requirement.

  The source WorkUnit requires the target WorkUnit. In other words, the source WorkUnit
  cannot be worked on until the target WorkUnit has been completed successfully.
  """
  class Meta:
    unique_together = ('source', 'target')

  source = ForeignKey(WorkUnit, db_index=True, on_delete=CASCADE, related_name='source+')
  target = ForeignKey(WorkUnit, db_index=True, on_delete=CASCADE, related_name='target+')

  @classmethod
  def add(cls, source, target):
    """Make WorkUnit source require WorkUnit target."""
    cls.objects.get_or_create(source=source, target=target)


class WorkExceptionLog(Model):
  """A log of an exception encountered while performing work."""

  class Meta:
    indexes = [
      GinIndex(fields=['search_vector'])
    ]

  timestamp = DateTimeField(default=timezone.now)

  CATEGORY_CHOICES = ((c, c.lower()) for c in WorkException.ALLOWED_CATEGORIES)
  category = CharField(max_length=20, choices=CATEGORY_CHOICES)

  work_unit = ForeignKey(WorkUnit, related_name='errors', db_index=True, on_delete=CASCADE)

  message = CharField(max_length=1000)

  # Tab-separated strings representing stack frames.  We use tab and not newline because the
  # text of the frames may contain embedded newlines.
  stacktrace = TextField(blank=True)

  search_vector = SearchVectorField(null=True)

  def stacktrace_frames(self, limit=None):
    """Return a list of short strings representing stack frames for the exception.

    :param limit: If specified, return this many innermost stack frames.
                  Otherwise, return all stack frames.
    """
    # Create a succinct representation of a stack frame.
    def shorten(frame):
      # Each frame contains multiple lines, but the first line is the one we care about,
      # that is, the one containing the file:lineno information.
      line_info = frame.split('\n')[0]

      # Remove uninteresting path prefixes, for brevity.
      def remove_prefix(s, prefix_ends_with):
        p = s.find(prefix_ends_with)
        if p >= 0:
          return s[p + len(prefix_ends_with):]
        return s
      # Remove the path/to/wheel/file.whl/ prefix from 3rdparty code paths.
      short = remove_prefix(line_info, '.whl/')
      # Remove the path/to/src/python/ prefix from local code paths.
      short = remove_prefix(short, '/src/python/')
      return short


    ret = [shorten(f) for f in self.stacktrace.split('\t')]
    if limit is not None:
      ret = ret[len(ret) - limit:]
    return ret

  def __str__(self):
    return '{}: {} on {}: {} at {}'.format(self.timestamp, self.category,
                                           self.work_unit, self.message,
                                           '\n'.join(self.stacktrace_frames()))


class WorkEpoch(Model):
  """A 'starting line' for an entire set of workunits and their requirements.

  Work completion can be measured against the lower bound of an epoch, so that WorkUnits
  completed successfully after an epoch's started_at timestamp are considered
  successful in that epoch.

  This loosely represents a "body" of work (e.g., a full crawl).
  """
  class Meta:
    get_latest_by = 'lower_bound'

  lower_bound = DateTimeField(db_index=True, default=timezone.now)

  @classmethod
  def get_current(cls):
    """Return the current epoch."""
    try:
      return WorkEpoch.objects.filter().latest()
    except WorkEpoch.DoesNotExist:
      return WorkEpoch.objects.create()

  def __str__(self):
    return 'WorkEpoch(lower_bound={})'.format(self.lower_bound)
