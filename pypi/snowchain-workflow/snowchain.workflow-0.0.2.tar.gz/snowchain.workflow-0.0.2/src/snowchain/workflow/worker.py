# coding=utf-8

from __future__ import (absolute_import, division, generators, nested_scopes,
                        print_function, unicode_literals, with_statement)


class Worker(object):
  """A base class for classes that do actual work.

  A new instance will be created for each attempt on each work unit, so the worker
  is allowed to store state on itself in do_work(), to be referenced in on_success()/on_failure().

  Each subclass of Worker must handle the work described by one subclass of WorkUnit.
  """
  # Subclasses can override to specify a default lease time for their work.
  DEFAULT_LEASE_SECS = 60

  # Subclasses must override to specify a single subclass of WorkUnit that they're capable of handling.
  work_unit_cls = None

  def __init__(self, *args, **kwargs):
    """Subclasses must pass any args/kwargs they don't themselves consume to this ctor.

    This future-proofs those subclasses against any changes to this ctor's arguments,
    even though the current implementation is a no-op.
    """
    super(Worker, self).__init__()

  def lease_secs(self):
    """Returns the number of seconds this worker will hold a lease on its work unit for.

    Subclasses can override DEFAULT_LEASE_SECS above to set a single lease length for all
    workers of that type, or they can override this method to set a custom lease length
    for each worker (possibly computed by examining self._work_unit).
    """
    return self.DEFAULT_LEASE_SECS

  def do_work(self, work_unit):
    """Implement this to perform the work described by work_unit.

    Implementations should:

    - Raise an exception to indicate that the work failed.
    - Return True to indicate that the work completed successfully.
    - Return False to indicate that the work should be rescheduled for another attempt.
      This is typically used when the worker needs to create more requirements for
      work_unit and wishes to retry only after those requirements are satisfied.

    This method must not modify work_unit or store a reference to it.
    It may store state on itself and use that to modify the work_unit in the on_*()
    handlers, e.g., to provide extra information about the handled condition.

    :param work_unit: Perform the work described by this WorkUnit instance.
    """
    raise NotImplementedError()

  def on_success(self, work_unit):
    """Override this to perform any database updates resulting from success of the work.

    These updates will happen in the same transaction as the one that updates the work unit state.

    This method is allowed to modify subclass fields on self.work_unit (but not fields of the
    WorkUnit superclass) and need not call save() on it, as the dispatcher will always do so.

    Note that:
      - The work_unit argument represents the same WorkUnit as the one passed to do_work,
        but it may not be the same object.
      - This method will not be called if the worker loses its lease before do_work() completes.

    :param work_unit: The successful work unit.
    """
    pass

  def on_reschedule(self, work_unit):
    """Override this to perform any database updates resulting from rescheduling the work.

    There are two ways to reschedule:

    - By requirement: Use this method to add new requirements to work_unit.  These will happen
      in the same transaction as the one that updates the work unit state.

    - By time: Return a timestamp from this method, and the work unit will not be attempted until
      after that timestamp.

    You may use both together, but if you use neither the work unit will be eligible to be
    re-attempted immediately, with no other state having changed, which makes rescheduling it
    pointless.

    This method is allowed to modify subclass fields on self.work_unit (but not fields of the
    WorkUnit superclass) and need not call save() on it, as the dispatcher will always do so.

    Note that:
      - The work_unit argument represents the same WorkUnit as the one passed to do_work,
        but it may not be the same object.
      - This method will not be called if the worker loses its lease before do_work() completes.

    :param work_unit: The failed work unit.
    :return: A timestamp to reschedule after.
    """
    pass

  def on_failure(self, work_unit):
    """Override this to perform any database updates resulting from failure of the work.

    These updates will happen in the same transaction as the one that updates the work unit state.

    This method is allowed to modify subclass fields on self.work_unit (but not fields of the
    WorkUnit superclass) and need not call save() on it, as the dispatcher will always do so.

    Note that:
      - The work_unit argument represents the same WorkUnit as the one passed to do_work,
        but it may not be the same object.
      - This method will not be called if the worker loses its lease before do_work() completes.

    :param work_unit: The failed work unit.
    """
    pass

  def on_complete(self):
    """Override this to perform any logging or other actions after the work attempt completes.

    Called after on_success/on_reschedule/on_failure and after the transaction that updates
    the work unit state completes.
    """
    pass
